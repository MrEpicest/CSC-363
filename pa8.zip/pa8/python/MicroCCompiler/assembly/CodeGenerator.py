import sys
import os

from .CodeObject import CodeObject
from .InstructionList import InstructionList
from .instructions import *
from ..compiler import *
from ..ast import *
from ..ast.visitor.AbstractASTVisitor import AbstractASTVisitor

class CodeGenerator(AbstractASTVisitor):

  def __init__(self):
    self.intRegCount = 0
    self.floatRegCount = 0
    self.intTempPrefix = 't'
    self.floatTempPrefix = 'f'

  def getIntRegCount(self):
    return self.intRegCount

  def getFloatRegCount(self):
    return self.floatRegCount




  def postprocessVarNode(self, node: VarNode) -> CodeObject:
    sym = node.getSymbol()

    co = CodeObject(sym)
    co.lval = True
    co.type = node.getType()

    return co


  
  def postprocessIntLitNode(self, node: IntLitNode) -> CodeObject:

    co = CodeObject()

    temp = self.generateTemp(Scope.Type.INT)
    val = node.getVal()
    # LI t2, 5
    co.code.append(Li(temp, val))
    co.temp = temp
    co.lval = False
    co.type = node.getType()


    return co


  def postprocessFloatLitNode(self, node: FloatLitNode) -> CodeObject:
    '''
    Float Literal:
    This will look a lot like the int literal node above
    Minor difference: use FImm instead of Li
    '''
    co = CodeObject()

    temp = self.generateTemp(Scope.Type.FLOAT)
    val = node.getVal()

    co.code.append(FImm(temp, val))
    co.temp = temp
    co.lval = False
    co.type = node.getType()

    return co



  def postprocessBinaryOpNode(self, node: BinaryOpNode, left: CodeObject, right: CodeObject) -> CodeObject:
    '''
    Step 0: Create new code object
    Step 1: Get code from left child and rvalify if needed
    Step 2: Add left code
    Step 3: Get code from right child and rvalify if needed
    Step 4: Add right code
    Step 5: Generate binary operation code using left/right's temps
    Step 6: Update code object's fields
    Step 7: Return it
    '''

    co = CodeObject()

    if left.lval:
      left = self.rvalify(left)

    co.code.extend(left.code)

    if right.lval:
        right = self.rvalify(right)

    co.code.extend(right.code)

    operator = node.getOp()

    if left.type is Scope.Type.INT and right.type is Scope.Type.INT:

      """if left.isVar():
      
        address = self.generateAddrFromVariable(left)
        addr_temp = self.generateTemp(Scope.Type.INT)
        co.code.append(La(addr_temp, address))

        left.temp = self.generateTemp(Scope.Type.INT)
        co.code.append(Lw(left.temp, addr_temp, 0))

      else:
        co.code.extend(left.code)

      if right.isVar():
      
        address = self.generateAddrFromVariable(right)
        addr_temp = self.generateTemp(Scope.Type.INT)
        co.code.append(La(addr_temp, address))

        right.temp = self.generateTemp(Scope.Type.INT)
        co.code.append(Lw(right.temp, addr_temp, 0))

      else:
        co.code.extend(right.code)"""
      
      temp = self.generateTemp(Scope.Type.INT)

      if operator == BinaryOpNode.OpType.ADD:
        co.code.append(Add(dest=temp, src1=left.temp, src2=right.temp))
      elif operator == BinaryOpNode.OpType.SUB:
        co.code.append(Sub(dest=temp, src1=left.temp, src2=right.temp))
      elif operator == BinaryOpNode.OpType.MUL:
        co.code.append(Mul(dest=temp, src1=left.temp, src2=right.temp))
      elif operator == BinaryOpNode.OpType.DIV:
        co.code.append(Div(dest=temp, src1=left.temp, src2=right.temp))

      co.type = left.type # update CodeObject type; left and right are the same type at this point

    elif left.type is Scope.Type.FLOAT and right.type is Scope.Type.FLOAT:

      temp = self.generateTemp(Scope.Type.FLOAT)

      if operator == BinaryOpNode.OpType.ADD:
        co.code.append(FAdd(dest=temp, src1=left.temp, src2=right.temp))
      elif operator == BinaryOpNode.OpType.SUB:
        co.code.append(FSub(dest=temp, src1=left.temp, src2=right.temp))
      elif operator == BinaryOpNode.OpType.MUL:
        co.code.append(FMul(dest=temp, src1=left.temp, src2=right.temp))
      elif operator == BinaryOpNode.OpType.DIV:
        co.code.append(FDiv(dest=temp, src1=left.temp, src2=right.temp))

      co.type = left.type # update CodeObject type; left and right are the same type at this point

    else:
      raise CodeGenerator(f"can't add {right.type} with {left.type}")
    

    co.temp = temp
    co.lval = False

    return co



  def postprocessUnaryOpNode(self, node: UnaryOpNode, expr: CodeObject) -> CodeObject:
    '''
    Unary Op Node would be telling us to do -(expr)
    Step 1: Generate blank code object
    Step 2: Get code for expr and rvalify if necessary
    Step 3: Add expr code after rvalifying
    Step 4: Generate instruction to negate 
    Step 5: Update temp/lval of resulting code object
    Step 6: Return it
    '''

    co = CodeObject()  # Step 0

    
    if expr.lval:
      expr = self.rvalify(expr)

    co.code.extend(expr.code) # Add in all the code required to get expr after rvalifying


    if expr.type == Scope.Type.INT:
      temp = self.generateTemp(Scope.Type.INT)
      co.code.append(Neg(src=expr.temp, dest=temp))
      

    elif expr.type == Scope.Type.FLOAT:
      temp = self.generateTemp(Scope.Type.FLOAT)
      co.code.append(FNeg(src=expr.temp, dest=temp))

    else:
      raise Exception("Non int/float type in unary op!")

    co.type = expr.type
    co.temp = temp
    co.lval = False 

    return co
  






  def postprocessAssignNode(self, node: AssignNode, left: CodeObject, right: CodeObject) -> CodeObject:
    co = CodeObject()

    assert(left.isVar())
    assert(left.lval)

    if right.lval:
      right = self.rvalify(right)

    co.code.extend(right.code)

    address = self.generateAddrFromVariable(left)
    addr_temp = self.generateTemp(Scope.Type.INT)
    co.code.append(La(addr_temp, address)) # La t0, address

    if right.type is Scope.Type.INT:
      co.code.append(Sw(right.temp, addr_temp, 0)) # Sw t1, 0(t0)   (assuming t1 has a value that we can store)
    elif right.type is Scope.Type.FLOAT:
      co.code.append(Fsw(right.temp, addr_temp, 0)) # Fsw f1, 0(t0)   (assuming t1 has a value that we can store)

    return co



  def postprocessStatementListNode(self, node: StatementListNode, statements: list) -> CodeObject:
    co = CodeObject()

    for subcode in statements:
      co.code.extend(subcode.code)

    co.type = None
    return co


	
  def postprocessReadNode(self, node: ReadNode, var: CodeObject) -> CodeObject:

    co = CodeObject()

    assert(var.isVar())

    if var.type is Scope.Type.INT:
      temp = self.generateTemp(Scope.Type.INT)
      co.code.append(GetI(temp))
      address = self.generateAddrFromVariable(var)
      temp2 = self.generateTemp(Scope.Type.INT)
      co.code.append(La(temp2, address))
      co.code.append(Sw(temp, temp2, '0'))

    elif var.type is Scope.Type.FLOAT:
      temp = self.generateTemp(Scope.Type.FLOAT)
      co.code.append(GetF(temp))
      address = self.generateAddrFromVariable(var)
      temp2 = self.generateTemp(Scope.Type.INT)
      co.code.append(La(temp2, address))
      co.code.append(Fsw(temp, temp2, '0'))
      pass

    else:
      raise Exception("Bad type in read node")


    return co


  def postprocessWriteNode(self, node: WriteNode, expr: CodeObject) -> CodeObject:

    co = CodeObject()

    mytype = expr.getType()

    if expr.isVar():

      # first get the address to load from and store it in a register (addr_temp)

      address = self.generateAddrFromVariable(expr)
      addr_temp = self.generateTemp(Scope.Type.INT)

      co.code.append(La(addr_temp, address)) # LA t0, address

      if mytype is Scope.Type.INT:

        temp = self.generateTemp(Scope.Type.INT)

        co.code.append(Lw(temp, addr_temp, 0))        

        co.code.append(PutI(temp))

      elif mytype is Scope.Type.FLOAT:

        
        temp = self.generateTemp(Scope.Type.FLOAT)

        co.code.append(Flw(temp, addr_temp, 0))

        co.code.append(PutF(temp))

      elif mytype is Scope.Type.STRING:

        co.code.append(PutS(addr_temp))

    else:

      co.code.extend(expr.code)

      if mytype is Scope.Type.INT:

        co.code.append(PutI(expr.temp))

      elif mytype is Scope.Type.FLOAT:

        co.code.append(PutF(expr.temp))

      elif mytype is Scope.Type.STRING:

        co.code.append(PutS(expr.temp))

    return co

  
  def postprocessReturnNode(self, node: ReturnNode, retExpr: CodeObject) -> CodeObject:

    co = CodeObject()

    if retExpr.lval is True:
      retExpr = self.rvalify(retExpr)

    co.code.extend(retExpr.code)
    co.code.append(Halt())
    co.type = None
    return co


  
  def generateTemp(self, t: Scope.Type) -> str:

    if t == Scope.Type.INT:
      s = self.intTempPrefix + str(self.intRegCount)
      self.intRegCount += 1
      return s
    elif t == Scope.Type.FLOAT:
      s = self.floatTempPrefix + str(self.floatRegCount)
      self.floatRegCount += 1
      return s
    else:
      raise Exception("Generating temp for bad type")



  def rvalify(self, lco : CodeObject) -> CodeObject:

    assert(lco.lval is True)
    assert(lco.isVar() is True)
    
    co = CodeObject()

    address = self.generateAddrFromVariable(lco)
    temp1 = self.generateTemp(Scope.Type.INT) # Addresses are always ints
    co.code.append(La(temp1, address)) # Load address (global only)

    if lco.type is Scope.Type.INT:
      temp2 = self.generateTemp(Scope.Type.INT)
      co.code.append(Lw(temp2, temp1, '0'))

    elif lco.type is Scope.Type.FLOAT:
      temp2 = self.generateTemp(Scope.Type.FLOAT)
      co.code.append(Flw(temp2, temp1, '0'))

    else:
      raise Exception("Bad type in rvalify!")

    co.type = lco.type
    co.lval = False
    co.temp = temp2


    return co






  def generateAddrFromVariable(self, lco: CodeObject) -> str:
    '''
    Changed type to return string.
    This function is responsible for returning the string that has the address of the variable.
    Right now it can only handle global variables.
    For globals: addresses are raw hex, e.g. 0x20000000
    Locals will be a number relative to the frame pointer
    '''

    assert(lco.isVar() is True)

    symbol = lco.getSTE()   # Get symbol from symbol table
    address = str(symbol.getAddress()) # Get address of variable

    return address
    